angular.module('pushpaApp', [
  'pushpaApp.controllers',
  'pushpaApp.services'
]);

